#ifndef _ccdl_math_hpp_
#define _ccdl_math_hpp_

#include "math/math.hpp"

#endif

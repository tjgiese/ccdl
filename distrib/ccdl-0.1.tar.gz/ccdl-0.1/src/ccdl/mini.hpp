#ifndef _ccdl_mini_hpp_
#define _ccdl_mini_hpp_

#include "mini/minimize.hpp"

#endif
